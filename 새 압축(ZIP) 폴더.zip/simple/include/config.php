<?php
    $mysqli = new mysqli("localhost", "root", "", "calendar2");
    if($mysqli->connect_errno){
        echo $mysqli->connect_errno;
        exit;
    }

    $board = new board('schedule');
 ?>
