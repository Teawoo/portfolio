<?php
/**
 *
 */
class board
{

    function __construct($schedule){
        $this->table = $schedule;
    }

    function getItem($sql, $mysqli){

    }
}

 ?>
