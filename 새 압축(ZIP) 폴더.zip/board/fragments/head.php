
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width" initial-scale="1">
<!-- 스타일 시트 참조 / css폴더의 bootstrap.css 참조 -->
<title>게시판</title>
<link rel="stylesheet" href="css/bootstrap.css">
		<link rel="stylesheet" href="css/custom.css">
				<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
				<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
