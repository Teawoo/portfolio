<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>게시판</title>
	</head>
	<body>
		<script>
			location.href='main.php'; // main.php
		
		
		</script>
	</body>
</html>