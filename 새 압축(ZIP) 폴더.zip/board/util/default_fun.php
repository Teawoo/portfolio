<?php
	function getMessagetPaging($page, $scale){
		
		// 페이징 관련 기능	
		$html = "";
		return $html; 
	}
?>