<?php
	include_once "./config.php";
?>
<!DOCTYPE html>
<html>
	<head>
		<?php include_once "./fragments/head.php";?>
	
	</head>
	<body>
		<!-- 표준 네비게이션 바 (화면 상단에 위치, 화면에 의존하여 확대 및 축소) -->
		<nav class="navbar navbar-default">
			<?php include_once "./fragments/header.php";?>
		</nav>
		<div class="container">
			<div class="jumbotron">
				<div class="container">
					<h1>메인페이지</h1>
					<p>PHP를 이용한 간단한 게시판,로그인,회원가입 기능을 구현해봤습니다.</p>
				</div>
			</div>
		</div>
		<div class="container"> 
    		<div id="carousel-example-generic" class="carousel slide">
	            <!-- Carousel items -->
	            <div class="carousel-inner">
	            	<div class="item active">
                		<img src="main.png" width="1200" height="400" alt="First slide">
                	</div>
	               
             	</div>
             	<!-- Controls -->
              	<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                	<span class="icon-prev"></span>
              	</a>
              	<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                	<span class="icon-next"></span>
              	</a>
          	</div>
  		</div>
  		<!-- JS 코드는 밑에 두는걸 권장 -->
  		<script src="./js/login.js"></script> 
		<script>
// 			$(function(){
// 				 $(".carousel").carousel(){ // 캐러셀 jQuery
// 					interval: 1000;
// 				 }); 
// 			});
		</script>
	</body>
</html>