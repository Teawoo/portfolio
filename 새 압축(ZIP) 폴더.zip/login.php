
<!DOCTYPE html>

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=devie-width, initial-scale=1.0">
	<title>Login 페이지</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="login.css">

</head>

<body class="login">

	<div id="particles-js">
		<canvas class="particles-js-canvas-el" width="725" height="856" style="width: 100%; height: 100%;">
	</div>
	<div class="container">
		<div class="login-container-wrapper clearfix">
			<div class="logo">
				<i class="fa fa-book"></i>
			</div>
			<div class="welcome"><strong>PORTFOLIO</strong> </div>

			<form class="form-horizontal login-form">
				<div class="form-group relative">
<input id="login_username" class="form-control input-lg" type="name" placeholder="이름" required autofocus>
				<i class="fa fa-user"></i>
				</div>
			  <div class="form-group">
			    <button type="button" onclick="location.href='portfolio.php'"class="btn btn-success btn-lg btn-block">
					 들어가기</button>
			  </div>
			</form>
		</div>
	</div>
	<footer><div class="copyright py-4 text-center text-white">
		<div class="container"><small>Copyright &copy; https://codepen.io/Peeyush200/pen/BQZQbb</small></div>
	</div></footer>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
	<script src="./login.js"></script>

  </body>
  </html>