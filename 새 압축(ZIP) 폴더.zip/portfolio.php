<!DOCTYPE html>
<html lang="ko">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>김태우 포트폴리오</title>
        <!-- 웹페이지 아이콘-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- 별 이미지-->
        <script src="https://use.fontawesome.com/releases/v5.15.3/js/all.js" crossorigin="anonymous"></script>
        <!-- 구글폰트-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <!-- css파일 연결-->
        <link href="portfolio.css" rel="stylesheet" />
    </head>
    <body id="page-top">
        <!-- 네비게이션-->
        <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand" href="#page-top">P.F</a>
                <button class="navbar-toggler text-uppercase font-weight-bold bg-primary text-white rounded" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    메뉴
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded" href="#portfolio">포트폴리오</a></li>
                        
                    </ul>
                </div>
            </div>
        </nav>
        <!-- body 윗부분-->
        <header class="masthead bg-primary text-white text-center">
            <div class="container d-flex align-items-center flex-column">
                <!-- body png파일-->
                <img class="masthead-avatar mb-5" src="assets/img/avataaars.png" alt="..." />
                <!-- 사진밑 제목부분-->
                <h1 class="masthead-heading text-uppercase mb-0">나만의 포트폴리오</h1>
                <!-- 라인,별 아이콘-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- 별밑에 이름-->
                <p class="masthead-subheading font-weight-light mb-0">안녕하세요 김태우입니다 잘부탁드립니다.</p>
            </div>
        </header>
        <!-- 포트폴리오 부분-->
        <section class="page-section portfolio" id="portfolio">
            <div class="container">
                <!-- 제목-->
                <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">Portfolio</h2>
                <!-- 라인,별 아이콘-->
                <div class="divider-custom">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- 그리드-->
                <div class="row justify-content-center">
                    <!-- 포트폴리오 1번-->
                    <div class="col-md-6 col-lg-4 mb-5">
                        <div class="portfolio-item mx-auto" data-bs-toggle="modal" data-bs-target="#portfolioModal1">
                            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                                <div class="portfolio-item-caption-content text-center text-white"><i class="fas fa-plus fa-3x"></i></div>
                            </div>
                            <img class="img-fluid" src="main.png" alt="..." />
                        </div>
                    </div>
                    <!-- 포트폴리오 2번-->
                    <div class="col-md-6 col-lg-4 mb-5">
                        <div class="portfolio-item mx-auto" data-bs-toggle="modal" data-bs-target="#portfolioModal2">
                            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                                <div class="portfolio-item-caption-content text-center text-white"><i class="fas fa-plus fa-3x"></i></div>
                            </div>
                            <img class="img-fluid" src="cal.png" alt="..." />
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </section>
            </div>
        </section>
        <!-- 푸터 부분-->
        <footer class="footer text-center">
            <div class="container">
                <div class="row">
                    <!-- 이메일,전화번호-->
                    <div class="col-lg-4 mb-5 mb-lg-0">
                        <h4 class="text-uppercase mb-4">개인정보</h4>
                        <p class="lead mb-0">
                            김태우 1995년 8월생
                            <br />
                            xodud044@gmail.com
                        </p>
                    </div>
                    <!--SNS-->
                    <div class="col-lg-4 mb-5 mb-lg-0">
                        <h4 class="text-uppercase mb-4">SNS</h4>
                        <a class="btn btn-outline-light btn-social mx-1" href="https://www.facebook.com/profile.php?id=100004647691621"><i class="fab fa-fw fa-facebook-f"></i></a>
                        <a class="btn btn-outline-light btn-social mx-1" href="https://www.instagram.com/xodud044/"><i class="fab fa-instagram"></i></a>
                        <a class="btn btn-outline-light btn-social mx-1" href="https://github.com/Teawoo"><i class="fab fa-github"></i></a>
                    </div>
                    <!--이력-->
                    <div class="col-lg-4">
                        <h4 class="text-uppercase mb-4">이력</h4>
                        <p class="lead mb-0">
                           사물인터넷 개발자 양성교육 이수 (한국직업능력교육원 안산)
                           <br>2021.05.07 ~ 2021.10.29
                           
                        </p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- 카피라이트-->
        <div class="copyright py-4 text-center text-white">
            <div class="container"><small>Copyright &copy; https://startbootstrap.com/theme/freelancer</small></div>
        </div>
        <!-- 포트폴리오 설명,링크-->
        <!-- 1번 포트폴리오-->
        <div class="portfolio-modal modal fade" id="portfolioModal1" tabindex="-1" aria-labelledby="portfolioModal1" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header border-0"><button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button></div>
                    <div class="modal-body text-center pb-5">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-8">
                                    <!-- 제목-->
                                    <h2 class="portfolio-modal-title text-secondary text-uppercase mb-0">게시판 구현</h2>
                                    <!-- 라인,별 아이콘-->
                                    <div class="divider-custom">
                                        <div class="divider-custom-line"></div>
                                        <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                        <div class="divider-custom-line"></div>
                                    </div>
                                    <!-- 1번 포트폴리오 이미지-->
                                    <a href="board/index.php"><img class="img-fluid rounded mb-5" src="main.png" alt="..." /></a>
                                   
                                    <!-- 1번 포트폴리오 설명-->
                                    <p class="mb-4">PHP를 이용한 회원가입,로그인,게시판을 구현해봤습니다.</p>
                                    

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- 2번 포트폴리오-->
        <div class="portfolio-modal modal fade" id="portfolioModal2" tabindex="-1" aria-labelledby="portfolioModal2" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header border-0"><button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button></div>
                    <div class="modal-body text-center pb-5">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-8">
                                    <!-- 제목-->
                                    <h2 class="portfolio-modal-title text-secondary text-uppercase mb-0">달력 구현</h2>
                                    <!-- 라인,별 아이콘-->
                                    <div class="divider-custom">
                                        <div class="divider-custom-line"></div>
                                        <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                        <div class="divider-custom-line"></div>
                                    </div>
                                    <!-- 2번 포트폴리오 이미지-->
                                    <a href="simple/index.php"><img class="img-fluid rounded mb-5" src="cal.png" alt="..." /></a>
                                    <!-- 2번 포트폴리오 설명-->
                                    <p class="mb-4">php를 이용한 간단한 달력을 구현해봤습니다.</p>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        </div>
       
        <!-- 부트스트랩 연동-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
        <!-- JS파일 연동-->
        <script src="portfolio.js"></script>
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
    </body>
</html>
